//Michael North
//
//Lab 1 Function Prototypes
//

/* in file printloop.c */
extern void printloop(char);
