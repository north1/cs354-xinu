//Michael North
//
//Lab 1 Function Prototypes
//

/* in file host2netl_asm.S */
extern long host2netl_asm(long);

/* in file printsegaddress.c */
extern void printsegaddress(void);

/* in file myprogA.c */
extern void myprogA();
extern int32 myfuncA(int32, int32);

/* in file printprocstks.c */
extern void printprocstks();

/* in file someprogA.c */
extern void someprogA();
extern void someprogB();
extern void rogueB();
extern int32 somefuncA(char);

